/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!***********************************************************************************************!*\
  !*** ../../../themes/metronic/html/demo1/src/js/custom/apps/subscriptions/add/bundle/main.js ***!
  \***********************************************************************************************/


// On document ready
KTUtil.onDOMContentLoaded(function () {
    // Modals
    KTModalCustomerSelect.init();    
    KTSubscriptionsProducts.init();
    KTSubscriptionsAdvanced.init();    
});
/******/ })()
;
//# sourceMappingURL=main.js.map