/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!********************************************************************************************!*\
  !*** ../../../themes/metronic/html/demo1/src/js/custom/apps/customers/view/bundle/main.js ***!
  \********************************************************************************************/


// On document ready
KTUtil.onDOMContentLoaded(function () {
	KTCustomerViewPaymentTable.init();
    KTCustomerViewInvoices.init();
	KTCustomerViewStatements.init();
	KTCustomerViewPaymentMethod.init();
	KTModalAddPayment.init();
	KTModalAdjustBalance.init();
	KTModalUpdateCustomer.init();	
});
/******/ })()
;
//# sourceMappingURL=main.js.map